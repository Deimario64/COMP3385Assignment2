<?php

namespace MVCFramework\Model;

class ORM extends AbstractModel
{
    public function find(int $id): array
    {
        // Implementation for finding data
    }

    public function save(array $data): void
    {
        // Implementation for saving data
    }

    public function validateForm(array $formData): bool
    {
        // Implementation for form validation
    }
}
