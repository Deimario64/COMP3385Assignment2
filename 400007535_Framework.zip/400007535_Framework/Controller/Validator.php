<?php

namespace MVCFramework\Controller;

class Validator implements ValidatorInterface
{
    public function validate(array $data): bool
    {
        // Implementation for validation
    }
}
